package com.example.salaty;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.hardware.*;
import android.content.*;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import android.graphics.Color;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class DiatelsPrayer extends AppCompatActivity implements SensorEventListener {
    private static boolean state=false;
    private ArrayList<String> list;
    private Button start;
    private Button stop;
    public  String dataPar="";
    public  String Copy_data="";
    public static final String TAG="DiatelsPrayer";
    private RequestQueue queue;
    private SensorManager sensorManager;
    private Sensor accelerometer ;
    private String  Type_of_pray="";
    private String data;
    public TextView salat_percent ;
    public TextView salat ;
    public TextView orderactivty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Type_of_pray = getIntent().getStringExtra("Type");
        setContentView(R.layout.activity_diatels_prayer);
        queue = Volley.newRequestQueue(this);
        list =new ArrayList<String>();
        salat_percent=findViewById(R.id.salat_percent);
        orderactivty=findViewById(R.id.orderactivty);
        salat=findViewById(R.id.salat_valid);

        /* the error is here becouse you don't defiand the text viwe
       if (orderactivty.isEnabled())
            orderactivty1.setEnabled(true);
            and you have must to handl the data in response method
            */
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(DiatelsPrayer.this,accelerometer,sensorManager.SENSOR_DELAY_FASTEST);
        Log.d(TAG,"onCreate: registerListener Sensor Service");
        start = (Button)findViewById(R.id.Start_btn);
        start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                if(!state) {
                    dataPar="";
                    //list=new ArrayList<String>();
                    state = true;
                    start.setText("Started");
                    start.setEnabled(false);
                    stop.setEnabled(true);
                }

            }
        });
        //stop.setEnabled(false);
        stop = (Button)findViewById(R.id.Stop_btn);
        stop.setEnabled(false);
        stop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                if(state) {
                    state = false;
                    start.setText("Start");
                    start.setEnabled(true);
                    EditText server_name =MainActivity.server_name;
                    //String url ="http://"+server_name.getText()+"/read_data?Type="+Type_of_pray+"&data="+dataPar;
                    String url ="http://"+server_name.getText()+"/read_data";
                    Log.d(TAG,"url is "+url);
                    String data = dataPar;
                    StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                            new Response.Listener<String>()
                            {
                                @Override
                                public void onResponse(String response) {
                                    // response
                                    Log.d(TAG, "Response: "+response);
                                    try {
                                        JSONObject data = new JSONObject(response);
                                        String salat1 = data.getString("salat");
                                        salat.setText(salat.getText()+salat1);
                                        String precent_correct1 = data.getString("precent_correct");
                                        salat_percent.setText(salat_percent.getText()+precent_correct1);
                                        // set the data from server to mobil here
                                        String orderactivty1 = data.getString("orderactivty");
                                        orderactivty.setText(orderactivty1);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }


                                }
                            },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    // error
                                    Log.d(TAG,"That didn't work!");
                                }
                            }
                    ) {

                        @Override
                        public Map<String, String> getParams()
                        {
                            Map<String, String>  params = new HashMap<String, String>();
                            params.put("Type", Type_of_pray);
                            params.put("data", dataPar);
                            //Log.d(TAG,"dataPar is "+dataPar);
                            return params;
                        }
                    };// Add the request to the RequestQueue.
                    //queue.add(stringRequest);
                    queue.add(postRequest);
                    //dataPar="";
                }
            }
        });

    }

    public void check(View view) {

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        //String s=sensorEvent.values[0]+";"+sensorEvent.values[1]+";"+sensorEvent.values[2]+"|";

        if (state) {
            //dataPar=dataPar+sensorEvent.values[0]+";"+sensorEvent.values[1]+";"+sensorEvent.values[2]+"|";
            Copy_data=Copy_data+sensorEvent.values[0]+";"+sensorEvent.values[1]+";"+sensorEvent.values[2]+"|";
            list.add("item");
            if (list.size()==80)
            {
                //state=false;
                dataPar=dataPar+ Copy_data;
                Copy_data="";

                list.clear();
            }
            //list.add(s);
            //Log.d(TAG,"opend read sernsor par value is"+dataPar);
            // tv1.setText(s);
        }

        //Log.d(TAG,"onSensorChanged X:"+sensorEvent.values[0]+" Y: "+sensorEvent.values[1]+" Z: "+sensorEvent.values[2]);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

}
