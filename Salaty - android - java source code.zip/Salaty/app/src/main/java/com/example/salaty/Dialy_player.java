package com.example.salaty;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Dialy_player extends AppCompatActivity {
    public static String selected_pray="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialy_player);
    }

    public void Fajer(View view) {
        Intent intentfajerDitals = new Intent(Dialy_player.this, DiatelsPrayer.class);
        intentfajerDitals.putExtra("Type","fajer");
        startActivity(intentfajerDitals);
    }

    public void zuhr(View view) {

    Intent zuher = new Intent(Dialy_player.this, DiatelsPrayer.class);
    zuher.putExtra("Type","zuher");
    startActivity(zuher);}

    public void asr(View view) {
        Intent aser = new Intent(Dialy_player.this, DiatelsPrayer.class);
        aser.putExtra("Type","aser");
        startActivity(aser);}

    public void magreb(View view) {
        Intent magreb = new Intent(Dialy_player.this, DiatelsPrayer.class);
        magreb.putExtra("Type","magreb");
        startActivity(magreb);}

    public void esha(View view) {
        Intent esha = new Intent(Dialy_player.this, DiatelsPrayer.class);
        esha.putExtra("Type","esha");
        startActivity(esha);}
}
