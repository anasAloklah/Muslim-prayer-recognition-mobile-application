package com.example.salaty;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;



public class MainActivity extends AppCompatActivity {
    public static   EditText server_name ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        server_name =(EditText)findViewById(R.id.sever_name);
    }

    public void login(View view) {
        Intent intent = new Intent(MainActivity.this, Dialy_player.class);
        startActivity(intent);
    }
    public void sensor(View view) {
        Intent intent = new Intent(MainActivity.this, View_data.class);
        startActivity(intent);
    }
}
