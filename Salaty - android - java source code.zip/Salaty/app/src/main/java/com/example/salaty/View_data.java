package com.example.salaty;

import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.hardware.*;
import android.content.*;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;
import com.android.volley.*;
import com.android.volley.toolbox.*;
import com.android.volley.toolbox.Volley;

public class View_data extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor accelerometer ;
    public static final String TAG="View_data";
    private static boolean state=false;
    public   TextView tv1 ;
    private RequestQueue queue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_data);
        tv1 = (TextView)findViewById(R.id.View1data);
        queue = Volley.newRequestQueue(this);
        Log.d(TAG,"onCreate: Initializion Sensor Service");
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(View_data.this,accelerometer,sensorManager.SENSOR_DELAY_UI);
        Log.d(TAG,"onCreate: registerListener Sensor Service");
        Button b = (Button)findViewById(R.id.button10);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                if(!state)
                    state=true;
                else
                {
                    //state=false;
                    EditText server_name =MainActivity.server_name;
                    String url ="http://"+server_name.getText()+"/check";
                    Log.d(TAG,"url is "+url);
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    // Display the first 500 characters of the response string.
                                    tv1.setText("Response is: "+ response);
                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            tv1.setText("That didn't work!");
                            Log.d(TAG,"That didn't work!");
                        }
                    });

// Add the request to the RequestQueue.
                    queue.add(stringRequest);
                }
            }
        });

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        String s="X:"+sensorEvent.values[0]+" Y: "+sensorEvent.values[1]+" Z: "+sensorEvent.values[2];
        if (!state)
            tv1.setText(s);
        else
        {

        }
        //Log.d(TAG,"onSensorChanged X:"+sensorEvent.values[0]+" Y: "+sensorEvent.values[1]+" Z: "+sensorEvent.values[2]);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    /*
    protected void onStop () {
        super.onStop();
        if (requestQueue != null) {
            requestQueue.cancelAll(TAG);
        }
    }*/

}
